import 'package:animator/animator.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:shoppingapp/apps/page1.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shoppingapp/apps/page2.dart';

import 'api project/loginpage.dart';
void main() {
  runApp(MaterialApp(
    home: loginpage(),
    builder: EasyLoading.init(),
  ));
}

class fp extends StatefulWidget {
  const fp({Key? key}) : super(key: key);

  @override
  State<fp> createState() => _fpState();
}

class _fpState extends State<fp> {
  List name = [
    "Renil Savani",
    "Jeet",
    "Clg Frd",
    "papa",
    "mom",
    "clg group",
    "pary group",
    "family group",
    "F creative",
    "clg sir"
  ];
  List msg = [
    "hyy",
    "what?",
    "call me",
    "sent photo",
    "bye",
    "come tomorrow",
    "today party time 11",
    "call from assa",
    "",
    "what we not come today"
  ];
  List time = [
    "9:10",
    "12:45",
    "8:00",
    "10:10",
    "1:06",
    "5:18",
    "5:05",
    "9:22",
    "7:06",
    "6:10"
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: DefaultTabController(
          length: 3,
          child: Scaffold(
            appBar: AppBar(
              actions: [
                IconButton(onPressed: () {}, icon: Icon(Icons.search)),
                IconButton(onPressed: () {}, icon: Icon(Icons.more_vert_sharp)),
              ],
              title: Text("WhatsApp"),
              backgroundColor: Colors.teal,
            ),
            body: Column(children: [
              TabBar(labelColor: Colors.teal, tabs: [
                Tab(
                  child: Text("CHATS"),
                ),
                Tab(
                  child: Text("STATUS"),
                ),
                Tab(
                  child: Text("CALLS"),
                )
              ]),
              Expanded(
                child: TabBarView(children: [
                  Container(
                    child: ListView.builder(
                      itemCount: name.length,
                      itemBuilder: (context, index) {
                        return Card(
                          margin: EdgeInsets.all(5),
                          child: ListTile(
                            onTap: () {},
                            leading: CircleAvatar(
                              backgroundColor: Colors.teal,
                            ),
                            title: Text("${name[index]}"),
                            subtitle: Text("${msg[index]}"),
                            trailing: Text("${time[index]}"),
                          ),
                        );
                      },
                    ),
                  ),
                  Container(
                    child: Center(child: Text("2st")),
                  ),
                  Container(
                    child: Center(child: Text("3st")),
                  )
                ]),
              )
            ]),
          )),
    );
  }
}





class MyCustomWidget extends StatefulWidget {
  @override
  _MyCustomWidgetState createState() => _MyCustomWidgetState();
}

class _MyCustomWidgetState extends State<MyCustomWidget> {
  @override
  Widget build(BuildContext context) {
    double _width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(),
      body: Center(
        child: Container(
          height: _width / 2.7,
          width: _width / 2.7,
          child: Animator<double>(
            duration: Duration(milliseconds: 1000),
            cycles: 0,
            curve: Curves.easeInOut,
            tween: Tween<double>(begin: 15.0, end: 25.0),
            builder: (context, animatorState, child) => Icon(
              Icons.audiotrack,
              size: animatorState.value * 5,
              color: Colors.blueGrey,
            ),
          ),
        ),
      ),
    );
  }
}